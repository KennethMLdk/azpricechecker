---
name: Bug report
about: Something is calculated or parsed incorrectly
labels: bug
---

**What happened**

**What you expected**

**Export type**
<!-- EA / MCA / FOCUS, actual or amortized, manual download or scheduled export -->

**Column headers of your CSV (first line only)**
<!-- Please do NOT attach your cost export. Headers and an anonymised example row are enough. -->
