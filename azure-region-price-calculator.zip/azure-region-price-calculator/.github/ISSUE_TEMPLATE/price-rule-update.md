---
name: Price rule update
about: Microsoft has changed an announced price increase, region list or exemption
labels: price-rules
---

**What changed**
<!-- e.g. "Norway East increase changed from 9 % to 7 %" -->

**Source**
<!-- Link to Microsoft announcement, Azure Service Health notice ID, or Microsoft Learn page -->

**Effective date**

**Suggested change to `app/rules.js`**
